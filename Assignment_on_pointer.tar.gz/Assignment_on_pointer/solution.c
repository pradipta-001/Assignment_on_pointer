#include <stdio.h>
#include <string.h>

void display_name(char **stu, int indx){
    
//type1
    printf("indx=%d, %s \n\n",indx, stu[indx]);
    
//type2
    // int name_size = strlen(stu[indx]);
    // int j=0;
    // while(j!=name_size){
    //     printf("%c",stu[indx][j]);
    //     j++;
    // }
    // printf("\n\n")
    
//type3
    // int j=0;
    // while(stu[indx][j]!='\0'){
    //     printf("%c",stu[indx][j]);
    //     j++;
    // }
    // printf("\n\n")
    
   return;
}


void vowel_count(char **stu, int indx){
    
    int cnt_vowel=0;
    int j=0;
    while(stu[indx][j]!='\0'){
        char ch=stu[indx][j];
        if(ch<=91){
            ch= ch + 32; // it the character is UPPER_CASE , coverting into LOWER_CASE
        }
        if(ch=='a' || ch=='e' || ch=='i' || ch=='o' || ch=='u' ){
            cnt_vowel++;
        }
        
        j++;
    }
    printf("indx=%d, name=%s  having number_of_vowel= %d \n\n",indx, stu[indx], cnt_vowel);
    
    return;
}


void longest_name(char **stu,int size){
    
    int longest_name_index=0;
    int max_len= 0;
    int i=0;
    for(int i=0; i<size; i++){
        int cur_name_len= strlen(stu[i]);
        if(cur_name_len > max_len){
            longest_name_index= i;
            max_len= cur_name_len;
        }
    }
    printf("longest_name= %s  having length= %ld\n\n", stu[longest_name_index], strlen(stu[longest_name_index]) );
    return;
}

void unique(char **stu, int size){ 
    
    int cnt=0;
    for(int i=0; i<size; i++){
        
        int len= strlen(stu[i]);
        if(len>=2){
            char first_char=stu[i][0];
            char last_char=stu[i][len-1];
            if(first_char <=91){
                first_char= first_char + 32; // it the character is UPPER_CASE , coverting into LOWER_CASE
            }
            if(last_char <=91){
                last_char= last_char + 32; // it the character is UPPER_CASE , coverting into LOWER_CASE
            }
            
            
            
            if(first_char=='a' && last_char=='a'){
                printf("%s ",stu[i]);
                cnt++;
            }
        }
    }
    if(cnt==0){
        printf("none");
    }
    printf("\n\n");
    return;
}

int main()
{
    char *students[] = {"Aakash", "Anirudha", "Vikas", "Vinay", "Rakesh", "Thomas", "Jerry", "Alekha","Daksh", "Peter" };
    
    int size= sizeof(students)/sizeof(students[0]);
    int indx;
    
    display_name (students, indx=3); // print the name of nth(index) student
    
    vowel_count (students, indx=3); // print the number of vowels in the name of nth(index) student
    
    longest_name (students, size); // print name of the student which has the longest name
    
    unique (students, size); // print name of the student whose name starts and ends with 'a'
    
    
    return 0;
}

